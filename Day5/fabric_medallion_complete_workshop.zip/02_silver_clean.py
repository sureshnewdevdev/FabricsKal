from pyspark.sql import functions as F, Window
from pyspark.sql import types as T
from functools import reduce
raw = spark.table("bronze_sales")
# Exact duplicate handling: one copy retained; a duplicate audit is saved.
source_cols = ["sale_id","sale_date","store_id","product_id","customer_id","quantity","unit_price"]
exact_dupes = raw.groupBy(*source_cols).count().filter("count > 1")
exact_dupes.write.format("delta").mode("overwrite").saveAsTable("silver_exact_duplicates")
unique = raw.dropDuplicates(source_cols)
# Conflicting rows with same sale_id are quarantined, not arbitrarily selected.
conflict_ids = unique.groupBy("sale_id").count().filter("count > 1").select("sale_id")
products = spark.table("bronze_products").select("product_id","product_name","category")
stores = spark.table("bronze_stores").select("store_id","store_name","city")
# Cast and enrich; ensure master keys are unique before joining.
assert products.groupBy("product_id").count().filter("count > 1").count() == 0
assert stores.groupBy("store_id").count().filter("count > 1").count() == 0
prepared = (unique
    .withColumn("parsed_date", F.to_date("sale_date", "yyyy-MM-dd"))
    .withColumn("qty", F.expr("try_cast(quantity as int)"))
    .withColumn("price", F.expr("try_cast(unit_price as decimal(18,2))"))
    .join(products, "product_id", "left")
    .join(stores, "store_id", "left")
    .join(conflict_ids.withColumn("has_conflict", F.lit(True)), "sale_id", "left"))
checks = [
 (F.col("sale_id").isNull() | (F.trim("sale_id") == ""), "missing_sale_id"),
 (F.col("parsed_date").isNull(), "invalid_date"),
 (F.col("customer_id").isNull() | (F.trim("customer_id") == ""), "missing_customer"),
 (F.col("qty").isNull() | (F.col("qty") <= 0), "invalid_quantity"),
 (F.col("price").isNull() | (F.col("price") < 0), "invalid_price"),
 (F.col("product_name").isNull(), "unknown_product"),
 (F.col("store_name").isNull(), "unknown_store"),
 (F.coalesce(F.col("has_conflict"), F.lit(False)), "conflicting_sale_id")]
reason_exprs = [F.when(cond, F.lit(reason)) for cond, reason in checks]
# For compatibility across Spark runtimes, use filter() to remove null elements.
checked = prepared.withColumn("reasons", F.filter(F.array(*reason_exprs), lambda x: x.isNotNull()))
rejected = checked.filter(F.size("reasons") > 0).withColumn("rejection_reason", F.concat_ws(",", "reasons"))
valid = (checked.filter(F.size("reasons") == 0)
    .select("sale_id", F.col("parsed_date").alias("sale_date"), "store_id", "store_name", "city",
            "product_id", "product_name", "category", "customer_id",
            F.col("qty").alias("quantity"), F.col("price").alias("unit_price"))
    .withColumn("revenue", (F.col("quantity") * F.col("unit_price")).cast("decimal(20,2)")))
valid.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable("silver_sales")
rejected.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable("silver_rejected_sales")
print("Valid", valid.count(), "Rejected unique records", rejected.count(), "Extra duplicate copies", exact_dupes.agg(F.sum(F.col("count")-1)).first()[0] or 0)
