from pyspark.sql import functions as F, types as T
# Attach this notebook to the target Lakehouse before running.
base = "Files/input"
sales_schema = T.StructType([
    T.StructField("sale_id", T.StringType()), T.StructField("sale_date", T.StringType()),
    T.StructField("store_id", T.StringType()), T.StructField("product_id", T.StringType()),
    T.StructField("customer_id", T.StringType()), T.StructField("quantity", T.StringType()),
    T.StructField("unit_price", T.StringType())])
products_schema = T.StructType([T.StructField(x, T.StringType()) for x in ["product_id","product_name","category"]])
stores_schema = T.StructType([T.StructField(x, T.StringType()) for x in ["store_id","store_name","city"]])
for filename, table, schema in [
    ("sales.csv","bronze_sales",sales_schema),
    ("products.csv","bronze_products",products_schema),
    ("stores.csv","bronze_stores",stores_schema)]:
    df = (spark.read.option("header",True).schema(schema).csv(f"{base}/{filename}")
          .withColumn("source_file", F.lit(filename))
          .withColumn("ingested_at", F.current_timestamp()))
    # Full snapshot mode for this workshop: rerunning replaces, never duplicates.
    df.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable(table)
    print(table, spark.table(table).count())
