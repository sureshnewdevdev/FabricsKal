from pyspark.sql import functions as F
silver = spark.table("silver_sales")
gold = (silver.groupBy("sale_date", "city", "store_id", "category")
    .agg(F.count("sale_id").alias("transaction_count"),
         F.sum("quantity").alias("units_sold"),
         F.sum("revenue").cast("decimal(20,2)").alias("total_revenue")))
gold.write.format("delta").mode("overwrite").option("overwriteSchema","true").saveAsTable("gold_daily_sales")
display(spark.table("gold_daily_sales").orderBy("sale_date", "city"))
assert silver.count() == 7, "Expected 7 valid sales"
assert float(silver.agg(F.sum("revenue")).first()[0]) == 8050.0, "Revenue mismatch"
assert spark.table("gold_daily_sales").count() == 7, "Expected 7 grouped rows"
print("PASS: 7 valid sales, 7 Gold groups, INR 8050 revenue")
