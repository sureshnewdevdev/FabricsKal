# Fabric Medallion Workshop Data
Upload sales.csv, products.csv, stores.csv to Lakehouse Files/input/.
Sales contains 12 rows, including one duplicate sale_id 1010, zero quantity, negative price, blank customer ID, and unknown store S99.
Expected valid rows after filtering and deduplication: 7 (1001-1006 and 1010), with revenue INR 8050.
