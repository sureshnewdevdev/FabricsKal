# GitHub Copilot prompts — paste into VS Code Copilot Chat

## 1. Review ingestion notebook
@workspace Review notebooks/01_bronze.py for Microsoft Fabric PySpark compatibility. Keep the Lakehouse relative Files path, Delta table name bronze_sales, and schema unchanged. Explain each line. Do not fabricate an execution result.

## 2. Review Silver data quality
@workspace Explain notebooks/02_silver.py line by line. Suggest improvements to null handling, deduplication, quarantine and idempotency. Preserve the sample schema. Provide tests for malformed dates, duplicate order_id and negative quantity.

## 3. Review Gold star schema
@workspace Review notebooks/03_gold.py. Explain fact vs dimension tables, date_key and joins. Flag assumptions about customer/product attributes changing over time. Keep deterministic keys and show expected validation queries.

## 4. Create pipeline documentation
@workspace Draft exact Fabric Data Factory UI steps for a Copy Data activity followed by three Notebook activities with Success dependencies. Include connection, source/destination paths, notebook selection and run monitoring. Do not claim you can create Fabric resources from VS Code without credentials or deployment configuration.

## 5. Power BI
@workspace Explain how to create a Fabric semantic model from four Gold tables and a report with total sales, order count, quantity, trend by date, category and region. Include relationship directions and DAX measures.
