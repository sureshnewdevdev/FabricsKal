# AI-first Microsoft Fabric sales medallion exercise

Use the HTML guide first. Open this folder in VS Code and use **GitHub Copilot Chat in Local session**. Source file: `data/sales_orders.csv`. The file has **10 orders** totaling **INR 182250**. Files in `notebooks` are reviewable reference solutions, not proof of deployment.

Fabric items: `lh_sales_medallion`, `pl_sales_medallion`, `01_bronze`, `02_silver`, `03_gold`. Fabric web portal is required for Lakehouse and pipeline setup; the Fabric Data Engineering VS Code extension supports notebook editing/publishing/remote execution. Create the Power BI semantic model explicitly.

**Before trying to run:** confirm your F2 capacity actually permits the requested Fabric Spark jobs and that your tenant/workspace grants notebook and pipeline permissions. F2 enabled plus Copilot accessible is not a guarantee that every feature operates without limits.
