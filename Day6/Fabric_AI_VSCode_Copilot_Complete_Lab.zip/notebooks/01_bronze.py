# 01_bronze.py — paste into a Fabric PySpark notebook attached to lh_sales_medallion
from pyspark.sql import functions as F
SOURCE = "Files/bronze/sales_orders.csv"
raw = spark.read.option("header", True).option("inferSchema", False).csv(SOURCE)
assert raw.count() > 0, "No rows copied to Bronze Files"
(raw.withColumn("ingested_at", F.current_timestamp())
    .withColumn("source_file", F.input_file_name())
    .write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    .saveAsTable("bronze_sales"))
print("Bronze rows:", spark.table("bronze_sales").count())
display(spark.table("bronze_sales"))
