# 02_silver.py — clean, validate, quarantine invalid rows and deduplicate
from pyspark.sql import functions as F
from pyspark.sql.window import Window
raw = spark.table("bronze_sales")
df = (raw.select(
    F.col("order_id").cast("int").alias("order_id"),
    F.to_date("order_date", "yyyy-MM-dd").alias("order_date"),
    F.trim("customer_id").alias("customer_id"),
    F.trim("customer_name").alias("customer_name"),
    F.trim("product_id").alias("product_id"),
    F.trim("product_name").alias("product_name"),
    F.trim("category").alias("category"),
    F.col("quantity").cast("int").alias("quantity"),
    F.col("unit_price").cast("decimal(12,2)").alias("unit_price"),
    F.trim("region").alias("region"),
    "ingested_at"))
valid = (F.col("order_id").isNotNull() & F.col("order_date").isNotNull() &
         F.col("customer_id").isNotNull() & (F.length("customer_id") > 0) &
         F.col("product_id").isNotNull() & (F.length("product_id") > 0) &
         F.col("quantity").isNotNull() & (F.col("quantity") > 0) &
         F.col("unit_price").isNotNull() & (F.col("unit_price") >= 0))
rejected = df.filter(~valid).withColumn("reject_reason", F.lit("Invalid required field/date/quantity/price"))
rejected.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_rejected_sales")
w = Window.partitionBy("order_id").orderBy(F.col("ingested_at").desc())
clean = (df.filter(valid).withColumn("rn", F.row_number().over(w))
         .filter("rn = 1").drop("rn")
         .withColumn("sales_amount", (F.col("quantity") * F.col("unit_price")).cast("decimal(14,2)")))
clean.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_sales")
print("Silver valid rows:", clean.count(), "Rejected rows:", rejected.count())
display(spark.table("silver_sales"))
